

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('sliders.create')); ?>" class="btn btn-primary mb-3"><i class="fas fa-plus  fa-sm  "></i> New Slide</a>

    <?php if(session('slide_create_msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('slide_create_msg')); ?>

        </div>
    <?php endif; ?>

    <h2 class="mb-3">Intro Slides</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Id</th>
                <th>Photo</th>
                <th>Caption</th>
                <th>Created</th>
                <th>Updated</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($sliders) > 0): ?>
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($slide->id); ?></td>
                        <td>
                            <img height="50" src="<?php echo e($slide->photo); ?>" alt="">
                        </td>
                        <td><a href="<?php echo e(route('sliders.edit', $slide->id)); ?>"><?php echo e($slide->caption); ?></a></td>
                        <td><?php echo e($slide->created_at->diffForHumans()); ?></td>
                        <td><?php echo e($slide->updated_at->diffForHumans()); ?></td>
                        <td>
                            <?php echo Form::open(['method' => 'DELETE', 'route' => ['sliders.destroy', $slide->id], 'class' => 'form-horizontal']); ?>

                            <?php echo Form::button('<i class="fas fa-trash-alt  fa-sm  "></i>', ['class' => 'btn btn-danger', 'type'=>'submit']); ?>

                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/sliders/index.blade.php ENDPATH**/ ?>