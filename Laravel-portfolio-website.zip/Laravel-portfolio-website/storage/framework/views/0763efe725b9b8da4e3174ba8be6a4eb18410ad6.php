<footer class="footer">
    <div class="container">
        <div class="footer-widgets">
            <div class="row">

                <?php $__currentLoopData = $footer_widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-sm-6 col-lg-3 widget-item">
                        <div class="widget">
                            <h4 class="widget-title"><?php echo e($widget->title); ?></h4>
                            <div class="widget-wrap">
                                <?php echo $widget->body; ?>

                            </div>
                        </div>
                        
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
        <p class="footer-copyright">&copy;2021 Copyright Reserved | <a href="<?php echo e(url('/')); ?>">www.tarikul.com</a></p>
    </div>
</footer><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/partials/site-footer.blade.php ENDPATH**/ ?>