

<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('user_create_message')): ?>
        <div class="alert alert-success mb-2">
            <?php echo e(session('user_create_message')); ?>

        </div>

        <?php elseif(session('delete_user_msg')): ?>
        <div class="alert alert-success mb-2">
            <?php echo e(session('delete_user_msg')); ?>

        </div>
    <?php endif; ?>

    <h1 class="mb-3">Users</h1>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Users</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTableUsers" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Photo</th>
                            <th>Name</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Email</th>
                            <th>Created</th>
                            <th>Updated</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Id</th>
                            <th>Photo</th>
                            <th>Name</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Email</th>
                            <th>Created</th>
                            <th>Updated</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if(! empty($users)): ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->id); ?></td>
                                    <td>
                                        <img height="44" src="<?php echo e($user->photo ? $user->photo->name : 'https://via.placeholder.com/50'); ?>" alt="">
                                    </td>
                                    <td><a href="<?php echo e(route('users.edit', $user->id)); ?>"><?php echo e($user->name); ?></a></td>
                                    <td><?php echo e($user->role->name); ?></td>
                                    <td>
                                        <?php if($user->is_active == 1): ?>
                                            <i class="fas fa-circle text-success"></i>
                                            Active
                                            <?php else: ?>
                                            <i class="fas fa-circle text-muted"></i>
                                            Not Active
                                        <?php endif; ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                                    <td><?php echo e($user->updated_at->diffForHumans()); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        // Call the dataTables jQuery plugin
        $(document).ready(function() {
            $('#dataTableUsers').DataTable();
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/users/index.blade.php ENDPATH**/ ?>