


<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-primary mb-4"><i class="fas fa-plus    fa-sm"></i> New Project</a>


    <?php if(session('project_action_success_msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('project_action_success_msg')); ?>

        </div>
    <?php endif; ?>

    <h2 class="mb-3">Projects</h2>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Projects</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped" id="dataTableProjects" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Thumbnail</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Link</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Id</th>
                            <th>Thumbnail</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Link</th>
                            <th>Description</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if(!empty($projects)): ?>
                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($project->id); ?></td>
                                    <td>
                                        <img style="max-height: 60px; border-radius: 4px;" src="<?php echo e($project->thumbnail); ?>" alt="">
                                    </td>
                                    <td style="min-width: 130px;"><a href="<?php echo e(route('projects.edit', $project->id)); ?>"><?php echo e($project->title); ?></a></td>
                                    <td style="min-width: 130px;"><?php echo e($project->category); ?></td>
                                    <td><a href="<?php echo e($project->link); ?>" target="_blank"><?php echo e($project->link); ?></a></td>
                                    <td>
                                        <div class="mb-1"><?php echo e($project->description); ?></div>
                                       <small class="mr-2">Created: <?php echo e($project->created_at->diffForHumans()); ?></small>
                                        <small>Updated: <?php echo e($project->updated_at->diffForHumans()); ?></small>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#dataTableProjects').DataTable({
                order: [0, 'desc']
            });
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/projects/index.blade.php ENDPATH**/ ?>