

<?php $__env->startSection('content'); ?>
    <iframe src="<?php echo e(url('laravel-filemanager?type=file')); ?>" style="width: 100%; height: 500px; overflow: hidden; border: none;"></iframe>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/medias/files.blade.php ENDPATH**/ ?>