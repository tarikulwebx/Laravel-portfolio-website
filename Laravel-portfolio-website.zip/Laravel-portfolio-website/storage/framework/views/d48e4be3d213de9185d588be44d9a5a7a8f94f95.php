

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <h2>Category: <?php echo e($category->name); ?></h2>
    <hr>

        <!-- Blog Post Section: START -->
        <div class="blog-posts">
            <div class="row"> 
    
                <?php if(!empty($posts)): ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Blog-post Item: START -->
                        <div class="col-md-4 blog-post-item">
                            <div class="card h-100" >
                                <div class="view overlay">
                                    <img class="card-img-top" src="<?php echo e($post->thumbnail ? $post->thumbnail : 'https://via.placeholder.com/300x150?text=No+Image'); ?>" alt="Thumbnail">
                                    <a href="#!">
                                        <div class="mask rgba-white-slight"></div>
                                    </a>
                                </div>

                                <div class="card-body d-flex flex-column">
                                    <div class="categories">
                                        <a href="/category/<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a>
                                    </div>
                                    
                                    <h4 class="card-title"><a href="/posts/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h4>
                                    <div class="card-text mb-0">
                                        <?php echo Str::limit($post->body, 100, '...'); ?>

                                    </div>
                                    <div class="mt-auto">
                                        <span class="post-time"><i class="fas fa-edit mr-1"></i> Posted <?php echo e($post->created_at->diffForHumans()); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Blog-post Item: END -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>


            </div>
        </div>
        
        <!-- Blog Post Section: END -->
        <div class="mt-2">
            <?php echo e($posts->links('vendor.pagination.bootstrap-4')); ?>

        </div>
        


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/posts/posts-by-category.blade.php ENDPATH**/ ?>