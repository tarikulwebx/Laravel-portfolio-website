

<?php $__env->startSection('content'); ?>
    <?php if(session('user_update_msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('user_update_msg')); ?>

        </div>
    <?php endif; ?>
    <h2 class="mb-3">Edit User: <a href="<?php echo e(route('users.edit', $user->id)); ?>"><?php echo e($user->name); ?></a></h2>
    <div class="row mb-5">
        <div class="col-lg-6">
            <?php echo Form::model($user, ['method' => 'PATCH', 'route' => ['users.update', $user->id], 'files'=>true]); ?>

                <div class="form-group">
                    <?php echo Form::label('name', 'Name: '); ?>

                    <?php echo Form::text('name', null, ['class' => ($errors->has('name')) ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
                </div>

                <div class="form-group">
                    <?php echo Form::label('email', 'Email: '); ?>

                    <?php echo Form::email('email', null, ['class' => ($errors->has('email')) ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('email')); ?></small>
                </div>
                
                <div class="form-group">
                    <?php echo Form::label('role_id', 'Role: '); ?>

                    <?php echo Form::select('role_id', [''=>'Choose Options', ] + $roles, null, ['class' => ($errors->has('role_id')) ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('role_id')); ?></small>
                </div>
                
                <div class="form-group<?php echo e($errors->has('is_active') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('is_active', 'Status:'); ?>

                    <?php echo Form::select('is_active',  [''=>'Choose Options', '1'=>'Active', '0'=>'Not Active'], null, ['class' => ($errors->has('is_active')) ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('is_active')); ?></small>
                </div>
    
                <div class="form-group">
                    <?php echo Form::label('photo_id', 'Photo:'); ?>

                    <img id="image_preview" class="d-block mb-2 img-rendering" height="80" src="<?php echo e($user->photo ? $user->photo->name : 'https://via.placeholder.com/70'); ?>" alt="">
                    <?php echo Form::file('photo_id', ['id' => 'image_input_with_preview', 'class' => ($errors->has('photo_id')) ? 'form-control-file is-invalid' : 'form-control-file']); ?>

                    <small class="text-danger"><?php echo e($errors->first('photo_id')); ?></small>
                </div>


                <div class="form-group">
                    <?php echo Form::label('password', 'Password: '); ?>

                    <?php echo Form::password('password', ['class' => ($errors->has('password')) ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('password')); ?></small>
                </div>
                
                <div class="text-right float-right">
                    <button type="button" class="btn btn-danger px-4 mr-2" data-toggle="modal" data-target="#deleteModal">Delete</button>
                    <?php echo Form::submit('Update User', ['class' => 'btn btn-success']); ?>

                </div>
            <?php echo Form::close(); ?>

            
        </div>

    </div>


    <!-- Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="deleteModalLabel">Delete User</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
            Are you sure? You wanna delete?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <?php echo Form::open(['method' => 'DELETE', 'route' => ['users.destroy', $user->id]]); ?>

                <?php echo Form::submit('Confirm', ['class' => 'btn btn-danger']); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>