

<?php $__env->startSection('content'); ?>

<a href="<?php echo e(route('skills.create')); ?>" class="btn btn-primary mb-4"><i class="fas fa-plus fa-sm  "></i> New Skill</a>

    <?php if(session('skill_create_msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('skill_create_msg')); ?>

        </div>
    <?php endif; ?>
    
    <?php if(session('skill_delete_msg')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('skill_delete_msg')); ?>

        </div>
    <?php endif; ?>
    
    



    <h2 class="mb-3">Services</h2>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Services</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped" id="dataTableSkills" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Skill</th>
                            <th>Progress</th>
                            <th>Created</th>
                            <th>Updated</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Id</th>
                            <th>Skill</th>
                            <th>Progress</th>
                            <th>Created</th>
                            <th>Updated</th>
                            <th>Delete</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if(!empty($skills)): ?>
                            <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($skill->id); ?></td>
                                    <td><a href="<?php echo e(route('skills.edit', $skill->id)); ?>"><?php echo e($skill->name); ?></a></td>
                                    <td><?php echo e($skill->progress); ?>%</td>
                                    <td><?php echo e($skill->created_at->diffForHumans()); ?></td>
                                    <td><?php echo e($skill->updated_at->diffForHumans()); ?></td>
                                    <td>
                                        <?php echo Form::open(['method' => 'DELETE', 'route' => ['skills.destroy', $skill->id]]); ?>

                                            <?php echo Form::button('<i class="fas fa-trash-alt fa-sm"></i>', ['class' => 'btn btn-danger', 'type'=>'submit']); ?>

                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#dataTableSkills').DataTable({
                order: [0, 'asc']
            });
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/skills/index.blade.php ENDPATH**/ ?>