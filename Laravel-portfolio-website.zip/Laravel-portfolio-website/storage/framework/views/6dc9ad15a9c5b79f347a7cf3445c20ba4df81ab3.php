


<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('skills.index')); ?>" class="btn btn-primary mb-4"><i class="fas fa-arrow-left  fa-sm  "></i> All Skills</a>

    <?php if(session('skill_update_msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('skill_update_msg')); ?>

        </div>
    <?php endif; ?>

    <h2 class="mb-3">Skill: <?php echo e($skill->name); ?></h2>

    <?php echo Form::model($skill, ['method' => 'PATCH', 'route' => ['skills.update', $skill->id], 'files' => true]); ?>

        <div class="row">
            <div class="col-md-8">
                <div class="form-group">
                    <?php echo Form::label('name', 'Skill Name: '); ?>

                    <?php echo Form::text('name', null, ['class' => $errors->has('name') ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
                </div>
                <div class="form-group">
                    <?php echo Form::label('progress', 'Progress(%): '); ?>

                    <?php echo Form::text('progress', null, ['class' => $errors->has('progress') ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('progress')); ?></small>
                </div>
                
            </div>
        </div>
        

        <?php echo Form::submit('Update Skill', ['class' => 'btn btn-success']); ?>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/skills/edit.blade.php ENDPATH**/ ?>