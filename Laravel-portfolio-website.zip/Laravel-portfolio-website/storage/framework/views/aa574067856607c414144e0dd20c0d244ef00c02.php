

<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('sliders.index')); ?>" class="btn btn-primary mb-3"> <i class="fas fa-arrow-left    "></i> All Slides</a>

    <h2 class="mb-3">New Slide</h2>

    <div class="row">
        <div class="col-lg-8">
            <?php echo Form::open(['method' => 'POST', 'route' => 'sliders.store']); ?>


                <div class="form-group">
                    <?php echo Form::label('photo', 'Photo: '); ?>

                    <div class="mb-3 d-block slider-holder" id="holder">
                        <img width="100" src="https://via.placeholder.com/300x200" alt="">
                    </div>
                    <div class="input-group">
                        <span class="input-group-btn">
                            <a id="lfm" data-input="photo" data-preview="holder" class="btn btn-secondary text-white px-4" style="border-top-right-radius: 0; border-bottom-right-radius: 0">
                            <i class="fa fa-picture-o"></i> Choose
                            </a>
                        </span>
                        <?php echo Form::text('photo', null, ['class' => $errors->has('photo') ? 'form-control is-invalid' : 'form-control']); ?>

                    </div>
                    <small class="text-danger"><?php echo e($errors->first('photo')); ?></small>
                </div>

                <div class="form-group">
                    <?php echo Form::label('caption', 'Caption: '); ?>

                    <?php echo Form::text('caption', null, ['class' => $errors->has('caption') ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('caption')); ?></small>
                </div>

                <?php echo Form::submit('Create', ['class' => 'btn btn-success']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/sliders/create.blade.php ENDPATH**/ ?>