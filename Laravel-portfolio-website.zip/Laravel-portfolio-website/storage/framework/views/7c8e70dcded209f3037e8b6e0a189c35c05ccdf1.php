

<?php $__env->startSection('content'); ?>

<a href="<?php echo e(route('services.create')); ?>" class="btn btn-primary mb-4"><i class="fas fa-plus fa-sm  "></i> New Service</a>

    <?php if(session('service_create_msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('service_create_msg')); ?>

        </div>
    <?php endif; ?>
    
    <?php if(session('service_delete_msg')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('service_delete_msg')); ?>

        </div>
    <?php endif; ?>
    
    



    <h2 class="mb-3">Services</h2>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Services</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped" id="dataTableServices" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Thumbnail</th>
                            <th>Service</th>
                            <th>Description</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Id</th>
                            <th>Thumbnail</th>
                            <th>Service</th>
                            <th>Description</th>
                            <th>Delete</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if(!empty($services)): ?>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($service->id); ?></td>
                                    <td>
                                        <img style="max-height: 60px; border-radius: 4px;" src="<?php echo e($service->thumbnail); ?>" alt="">
                                    </td>
                                    <td style="min-width: 130px;"><a href="<?php echo e(route('services.edit', $service->id)); ?>"><?php echo e($service->name); ?></a></td>
                                    <td>
                                        <div class="mb-1"><?php echo e($service->description); ?></div>
                                        <small class="mr-2">Created: <?php echo e($service->created_at->diffForHumans()); ?></small>
                                        <small>Updated: <?php echo e($service->updated_at->diffForHumans()); ?></small>
                                    </td>
                                    <td>
                                        <?php echo Form::open(['method' => 'DELETE', 'route' => ['services.destroy', $service->id]]); ?>

                                            <?php echo Form::button('<i class="fas fa-trash-alt fa-sm"></i>', ['class' => 'btn btn-danger', 'type'=>'submit']); ?>

                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#dataTableServices').DataTable({
                order: [0, 'asc']
            });
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/services/index.blade.php ENDPATH**/ ?>