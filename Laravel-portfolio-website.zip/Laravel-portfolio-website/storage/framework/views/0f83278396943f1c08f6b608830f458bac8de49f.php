

<?php $__env->startSection('content'); ?>

<a href="<?php echo e(route('contacts.index')); ?>" class="btn btn-primary mb-4">All Messages</a>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul>
                    <li><?php echo e($error); ?></li>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <?php if(session('contact_delete_msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('contact_delete_msg')); ?>

        </div>
    <?php endif; ?>
    
    <h2 class="mb-3">Messages to read</h2>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Messages</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped" id="dataTableContacts" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Sender</th>
                            <th>Message</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Id</th>
                            <th>Sender</th>
                            <th>Message</th>
                            <th>Delete</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if(!empty($contacts)): ?>
                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($contact->id); ?></td>
                                    <td>
                                        <Strong><?php echo e($contact->name); ?></Strong>
                                        <small><a href="mailto:<?php echo e($contact->email); ?>"><?php echo e($contact->email); ?></a></small>
                                    </td>
                                    <td>
                                        <strong class="d-block mb-2"><em>Subject: </em><?php echo e($contact->subject); ?></strong>
                                        <div class="mb-2"><?php echo e($contact->message); ?></div>
                                        <small class=""><em>Data Time:  <?php echo e($contact->created_at); ?></em></small> 
                                        
                                        <a href="javascript:void(0)" class="contact-read contact-read-<?php echo e($contact->id); ?> text-decoration-none ml-2 <?php echo e($contact->read == 1 ? 'd-none' : ''); ?>" data-id="<?php echo e($contact->id); ?>">Mark as read <i class="far fa-check-circle fa-sm"></i></a>
                                        <a href="javascript:void(0)" class="contact-unread contact-unread-<?php echo e($contact->id); ?> text-decoration-none ml-2 text-danger <?php echo e($contact->read == 0 ? 'd-none' : ''); ?>" data-id="<?php echo e($contact->id); ?>">Mark as unread <i class="far fa-times-circle fa-sm"></i></a>
                                    </td>
                                    <td>
                                        <?php echo Form::open(['method' => 'DELETE', 'route' => ['contacts.destroy', $contact->id]]); ?>

                                        <?php echo Form::button('<i class="fas fa-trash-alt"></i>', ['class' => 'btn btn-danger btn-sm', 'type'=>'submit']); ?>

                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#dataTableContacts').DataTable({order:[[0,"desc"]]});
        });


        $('.contact-read').click(function(){
            var contactId = $(this).data('id');
            var url ='/admin/contacts/'+contactId;
            axios.put(url, {
                read: 1,
            })
            .then(res => {
                if (res.status == 200) {
                    if (res.data == 1) {
                        $('.contact-read-'+contactId).addClass('d-none');
                        $('.contact-unread-'+contactId).removeClass('d-none');
                        toastr.success('Marked as read');
                    } else {
                        toastr.error('Update failed');
                    }
                } else {
                    toastr.error('Update failed');
                }
            })
            .catch(err => {
                toastr.error(err);
            })
        });

        $('.contact-unread').click(function(){
            var contactId = $(this).data('id');
            var url ='/admin/contacts/'+contactId;
            axios.put(url, {
                read: 0,
            })
            .then(res => {
                if (res.status == 200) {
                    if (res.data == 1) {
                        $('.contact-unread-'+contactId).addClass('d-none');
                        $('.contact-read-'+contactId).removeClass('d-none');
                        toastr.success('Marked as unread');
                    } else {
                        toastr.error('Update failed');
                    }
                } else {
                    toastr.error('Update failed');
                }
            })
            .catch(err => {
                toastr.error(err);
            })
        });

        


    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/contacts/unread-contacts.blade.php ENDPATH**/ ?>