

<?php $__env->startSection('content'); ?>
    <?php if(session('comment_delete_msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('comment_delete_msg')); ?>

        </div>
    <?php endif; ?>
    <h2 class="mb-4">All Comments</h2>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Comments</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTableComments" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Author</th>
                            <th>Post</th>
                            <th>Comment</th>
                            <th>Status</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Id</th>
                            <th>Author</th>
                            <th>Post</th>
                            <th>Comment</th>
                            <th>Status</th>
                            <th>Delete</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if(!empty($comments)): ?>
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($comment->id); ?></td>
                                    <td style="max-width: 170px">
                                        <span class=""><?php echo e($comment->author); ?></span>
                                        <small><?php echo e($comment->email); ?></small>
                                    </td>
                                    <td><a href="<?php echo e(route('single-post', $comment->post->id)); ?>"><?php echo e($comment->post->title); ?></a></td>
                                    <td>
                                        <?php echo e(Str::limit($comment->body, 120, '...')); ?>

                                        <div>
                                            <a href="" style="font-size: 14px;" class="text-decoration-none font-weight-bold" data-toggle="collapse" data-target="#replies-<?php echo e($comment->id); ?>"><small><i class="fas fa-eye fa-1x"></i></small> Replies (<?php echo e(count($comment->replies)); ?>)</a>
                                            <div id="replies-<?php echo e($comment->id); ?>" class="collapse">
                                                <?php if($comment->replies): ?>
                                                    <ol class="">
                                                        <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li class="text-black">
                                                                <small><?php echo e(Str::limit($reply->body, 60, '...')); ?> 
                                                                    <a id="approveReplyBtn-<?php echo e($reply->id); ?>" href="javasript:void(0)" class="approveReplyBtn text-decoration-none font-weight-bold <?php echo e($reply->is_active == 1 ? 'd-none' : ''); ?>" data-id="<?php echo e($reply->id); ?>">Approve</a>
                                                                    <a id="unApproveReplyBtn-<?php echo e($reply->id); ?>" href="javasript:void(0)" class="unApproveReplyBtn text-decoration-none font-weight-bold <?php echo e($reply->is_active == 0 ? 'd-none' : ''); ?>" data-id="<?php echo e($reply->id); ?>">Unapprove</a>
                                                                </small> 
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ol>
                                                <?php endif; ?>
                                                
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <button id="approveCommentBtn-<?php echo e($comment->id); ?>" class="approveCommentBtn btn btn-primary btn-sm <?php echo e($comment->is_active == 1 ? 'd-none' : ''); ?>" data-id="<?php echo e($comment->id); ?>">Approve</button>
                                        <button id="unApproveCommentBtn-<?php echo e($comment->id); ?>" class="unApproveCommentBtn btn btn-warning btn-sm <?php echo e($comment->is_active == 0 ? 'd-none' : ''); ?>" data-id="<?php echo e($comment->id); ?>">Unapprove</button>
                                    </td>
                                    <td>

                                        <?php echo Form::open(['method' => 'DELETE', 'route' => ['comments.destroy', $comment->id]]); ?>

                                        <?php echo Form::submit('Delete', ['class' => 'deleteCommentBtn btn btn-danger btn-sm']); ?>

                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

    <script>
        
        $(document).ready(function() {
            $('#dataTableComments').DataTable({
                "pageLength": 10,
                order: [[ 0, "desc" ]],
            });
        });


        $('.approveCommentBtn').click(function(){
            var commentId = $(this).data('id');
            var isActive = 1; //aprove
            
            var url = '/admin/comments/'+commentId;
            axios.put(url, {
                id: commentId,
                is_active: isActive,
            })
            .then(res => {
                if (res.status == 200) {
                    if(res.data == 1) {
                        toastr.success('Comment Approved');
                        $('#approveCommentBtn-'+commentId).addClass('d-none');
                        $('#unApproveCommentBtn-'+commentId).removeClass('d-none');
                    } else {
                        toastr.error('Approve failed');
                        $('#approveCommentBtn-'+commentId).removeClass('d-none');
                        $('#unApproveCommentBtn-'+commentId).addClass('d-none');
                    }
                } else {
                    toastr.error('Approve failed');
                    $('#approveCommentBtn-'+commentId).removeClass('d-none');
                    $('#unApproveCommentBtn-'+commentId).addClass('d-none');
                }
            })
            .catch(err => {
                toastr.error('Error occured');
                $('#approveCommentBtn-'+commentId).removeClass('d-none');
                $('#unApproveCommentBtn-'+commentId).addClass('d-none');
            })

        });


        $('.unApproveCommentBtn').click(function(){
            var commentId = $(this).data('id');
            var isActive = 0; //aprove
            
            var url = '/admin/comments/'+commentId;
            axios.put(url, {
                id: commentId,
                is_active: isActive,
            })
            .then(res => {
                if (res.status == 200) {
                    if(res.data == 1) {
                        toastr.success('Comment Unapproved');
                        $('#approveCommentBtn-'+commentId).removeClass('d-none');
                        $('#unApproveCommentBtn-'+commentId).addClass('d-none');
                    } else {
                        toastr.error('Approve failed');
                        $('#approveCommentBtn-'+commentId).addClass('d-none');
                        $('#unApproveCommentBtn-'+commentId).removeClass('d-none');
                    }
                } else {
                    toastr.error('Approve failed');
                    $('#approveCommentBtn-'+commentId).addClass('d-none');
                    $('#unApproveCommentBtn-'+commentId).removeClass('d-none');
                }
            })
            .catch(err => {
                toastr.error('Error occured');
                $('#approveCommentBtn-'+commentId).addClass('d-none');
                $('#unApproveCommentBtn-'+commentId).removeClass('d-none');
            })

        });


        $('.approveReplyBtn').click(function(){
            var replyId = $(this).data('id');
            var isActive = 1; //aprove
            
            var url = '/admin/comment/replies/'+replyId;
            axios.put(url, {
                id: replyId,
                is_active: isActive,
            })
            .then(res => {
                if (res.status == 200) {
                    if(res.data == 1) {
                        toastr.success('Reply Approved');
                        $('#approveReplyBtn-'+replyId).addClass('d-none');
                        $('#unApproveReplyBtn-'+replyId).removeClass('d-none');
                    } else {
                        toastr.error('Approve failed');
                        $('#approveReplyBtn-'+replyId).removeClass('d-none');
                        $('#unApproveReplyBtn-'+replyId).addClass('d-none');
                    }
                } else {
                    toastr.error('Approve failed');
                    $('#approveReplyBtn-'+replyId).removeClass('d-none');
                    $('#unApproveReplyBtn-'+replyId).addClass('d-none');
                }
            })
            .catch(err => {
                toastr.error('Error occured');
                $('#approveReplyBtn-'+replyId).removeClass('d-none');
                $('#unApproveReplyBtn-'+replyId).addClass('d-none');
            })

        });

        $('.unApproveReplyBtn').click(function(){
            var replyId = $(this).data('id');
            var isActive = 0; //aprove
            
            var url = '/admin/comment/replies/'+replyId;
            axios.put(url, {
                id: replyId,
                is_active: isActive,
            })
            .then(res => {
                if (res.status == 200) {
                    if(res.data == 1) {
                        toastr.success('Comment Unapproved');
                        $('#approveReplyBtn-'+replyId).removeClass('d-none');
                        $('#unApproveReplyBtn-'+replyId).addClass('d-none');
                    } else {
                        toastr.error('Approve failed');
                        $('#approveReplyBtn-'+replyId).addClass('d-none');
                        $('#unApproveReplyBtn-'+replyId).removeClass('d-none');
                    }
                } else {
                    toastr.error('Approve failed');
                    $('#approveReplyBtn-'+replyId).addClass('d-none');
                    $('#unApproveReplyBtn-'+replyId).removeClass('d-none');
                }
            })
            .catch(err => {
                toastr.error('Error occured');
                $('#approveReplyBtn-'+replyId).addClass('d-none');
                $('#unApproveReplyBtn-'+replyId).removeClass('d-none');
            })

        });



    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/comments/index.blade.php ENDPATH**/ ?>