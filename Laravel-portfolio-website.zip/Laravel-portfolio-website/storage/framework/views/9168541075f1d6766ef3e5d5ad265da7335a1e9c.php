

<?php $__env->startSection('content'); ?>
    <h2 class="mb-4">Widgets</h2>
    <div class="row">
        <?php $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6 mb-4 pb-3">

                <div id="success_msg_<?php echo e($widget->id); ?>" class="alert alert-success d-none"></div>

                <h3><?php echo e(Str::title(str_replace('_', ' ', $widget->location))); ?></h3>
                <div class="form-group">
                    <label for="title">Widget Title: </label>
                    <input type="text" name="title" id="title_<?php echo e($widget->id); ?>" class="form-control" value="<?php echo e($widget->title); ?>">
                    <small id="title_error_msg_<?php echo e($widget->id); ?>" class="text-danger d-none"></small>
                </div>
                <div class="form-group">
                    <label for="body">Widget Body: </label>
                    <textarea name="body" id="body_<?php echo e($widget->id); ?>" class="tinyWidgetEditor form-control"><?php echo $widget->body; ?></textarea>
                    <small id="body_error_msg_<?php echo e($widget->id); ?>" class="text-danger d-none"></small>
                </div>
                <button class="updateWidgetBtn btn btn-primary btn-sm px-3" data-id="<?php echo e($widget->id); ?>">Update</button>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        
        tinymce.init({
            selector: 'textarea.tinyWidgetEditor',
            height: 300,
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table paste code help wordcount'
            ],
            toolbar: 'formatselect | ' +
            'bold italic backcolor | alignleft aligncenter ' +
            'alignjustify | bullist numlist | code',
            content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
        });



        $('.updateWidgetBtn').click(function(){
            
            var id = $(this).data('id');
            var title = $('#title_'+id).val();
            var body = tinymce.get("body_"+id).getContent({format: "raw"});

            var errorFlag = 0;

            if($.trim(title).length == 0) {
                $('#title_error_msg_'+id).removeClass('d-none').html('The title field is empty.');
                $('#title_'+id).addClass('is-invalid');
                errorFlag = 1;
            } else {
                $('#title_error_msg_'+id).addClass('d-none');
                $('#title_'+id).removeClass('is-invalid');
            }
            if($.trim(body).length == 0) {
                $('#body_error_msg_'+id).removeClass('d-none').html('The body field is empty.');
                $('#body_'+id).addClass('is-invalid');
                errorFlag = 1;
            } else {
                $('#body_error_msg_'+id).addClass('d-none')
                $('#body_'+id).removeClass('is-invalid');
            }

            // If no errors found
            if (errorFlag == 0) {
                var url = '/admin/widgets/'+id;
                axios.put(url, {
                    title: title,
                    body: body,
                })
                .then(res => {
                    if(res.status == 200) {
                        if(res.data == 1) {
                            $('#success_msg_'+id).removeClass('alert-danger d-none').addClass('alert-success').html('Update success!');
                        } else {
                            $('#success_msg_'+id).removeClass('alert-success d-none').addClass('alert-danger').html('Update failed!');
                        }
                    } else {
                        $('#success_msg_'+id).removeClass('alert-success d-none').addClass('alert-danger').html('Update failed!');
                    }
                })
                .catch(err => {
                    $('#success_msg_'+id).removeClass('alert-success d-none').addClass('alert-danger').html(err);
                })
            }
            
            
        });


    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/widgets/index.blade.php ENDPATH**/ ?>