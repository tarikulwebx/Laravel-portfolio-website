<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <!-- Title -->
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/libs.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

    <?php echo $__env->yieldContent('styles'); ?>

</head>

<body>
    <!-- Header: START -->
    <header class="header">
        <!-- Navbar: START -->
        <?php echo $__env->make('partials.site-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Navbar: END -->
    </header>
    <!-- Header: END -->


    <div class="main">
        <?php echo $__env->yieldContent('content'); ?>
    </div>



    <!-- Footer: START -->
    <?php echo $__env->make('partials.site-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer: END -->
    
    <!-- JS Libraries -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/libs.js')); ?>"></script>
    <script src="<?php echo e(asset('js/smooth-scroll.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/layouts/home-master.blade.php ENDPATH**/ ?>