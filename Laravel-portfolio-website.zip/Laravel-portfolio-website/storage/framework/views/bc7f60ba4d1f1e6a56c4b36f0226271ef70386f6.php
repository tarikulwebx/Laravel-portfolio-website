

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul class="m-0">
                    <li><?php echo e($error); ?></li>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <?php if(session('category_create_msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('category_create_msg')); ?>

        </div>
        <?php elseif(session('category_update_msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('category_update_msg')); ?>

        </div>
        <?php elseif(session('category_delete_msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('category_delete_msg')); ?>

        </div>
        
    <?php endif; ?>
    <h2 class="mb-3">Categories</h2>
    <div class="row">
        <div class="col-lg-5 mb-4">
            <?php echo Form::open(['method' => 'POST', 'route' => 'categories.store']); ?>

                <div class="form-group">
                    <?php echo Form::label('name', 'Name'); ?>

                    <?php echo Form::text('name', null, ['class' => ($errors->has('name')) ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
                </div>
                <?php echo Form::submit('Create Category', ['class' => 'btn btn-info']); ?>

            <?php echo Form::close(); ?>

        </div>
        <div class="col-lg-7">
            
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">All Categories</h6>
                </div>
                <div class="card-body">
                    <?php if($categories): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTableCategories" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Created</th>
                                        <th>Updated</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Created</th>
                                        <th>Updated</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($category->id); ?></td>
                                            <td><a href="<?php echo e(route('categories.edit', $category->id)); ?>"><?php echo e($category->name); ?></a></td>
                                            <td><?php echo e($category->created_at->diffForHumans()); ?></td>
                                            <td><?php echo e($category->updated_at->diffForHumans()); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <?php else: ?>
                            <h3>No category yet!</h3>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>