<nav class="navbar navbar-expand-lg navbar-dark orange fixed-top scrolling-navbar">
    <div class="container-fluid">
        <a class="navbar-brand text-uppercase d-flex align-items-center" href="<?php echo e(url('/')); ?>">
            <img class="mr-2" src="<?php echo e(asset('images/tarikul.png')); ?>" alt="">
            <span>Tarikul</span>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#top-navbar" aria-controls="top-navbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="top-navbar">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/')); ?>#services">Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/')); ?>#courses">Courses</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/')); ?>#projects">Projects</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/')); ?>#articles">Blog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/')); ?>#contact">Contact</a>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto nav-flex-icons">
                <?php if($about->facebook != null): ?>
                <li class="nav-item">
                    <a href="<?php echo e($about->facebook); ?>" class="nav-link waves-effect waves-light">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($about->twitter != null): ?>
                <li class="nav-item">
                    <a href="<?php echo e($about->twitter); ?>" class="nav-link waves-effect waves-light">
                        <i class="fab fa-twitter"></i>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($about->github != null): ?>
                <li class="nav-item">
                    <a href="<?php echo e($about->github); ?>" class="nav-link waves-effect waves-light">
                        <i class="fab fa-github"></i>
                    </a>
                </li>
                <?php endif; ?>

                
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-user"></i>
                        <?php if(Auth::user()): ?>
                            <?php echo e(Auth::user()->name); ?>

                        <?php endif; ?>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-default" aria-labelledby="navbarDropdownMenuLink-333">
                        <?php if(Auth::guest()): ?>
                            <a class="dropdown-item" href="<?php echo e(url('/login')); ?>"><i class="fas fa-sign-in-alt mr-2"></i> Login</a>
                            <a class="dropdown-item" href="<?php echo e(url('/register')); ?>"><i class="fas fa-user-circle    mr-2"></i> Register</a>
                            <?php else: ?>
                            <?php if(Auth::user()->is_admin() && Auth::user()->is_active == 1): ?>
                                <a class="dropdown-item" href="<?php echo e(url('/admin')); ?>"><i class="fas fa-user-cog   mr-2 "></i> Admin</a>
                            <?php endif; ?>

                            <?php if(Auth::user()): ?>
                                <a class="dropdown-item" href="<?php echo e(route('show-profile', Auth::user()->slug)); ?>"><i class="fas fa-user-alt    mr-2"></i> Profile</a>
                            <?php endif; ?>
                            
                            <a class="dropdown-item" href="<?php echo e(url('/logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fas fa-sign-in-alt mr-2"></i> Logout</a>
                            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;"><?php echo e(csrf_field()); ?> </form>
                        <?php endif; ?>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/partials/site-navbar.blade.php ENDPATH**/ ?>