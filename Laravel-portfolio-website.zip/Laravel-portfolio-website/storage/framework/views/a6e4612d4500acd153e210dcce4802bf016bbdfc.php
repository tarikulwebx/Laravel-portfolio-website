

<?php $__env->startSection('content'); ?>
    <?php if(session('about_update_msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('about_update_msg')); ?>

        </div>
    <?php endif; ?>
    <h2 class="mb-3">About Info</h2>

    <?php echo Form::model($about, ['method' => 'PATCH', 'route' => ['about.update', $about->id], 'files' => true]); ?>

        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo Form::label('name', 'Name: '); ?>

                    <?php echo Form::text('name', null, ['class' => $errors->has('name') ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo Form::label('profession', 'Profession: '); ?>

                    <?php echo Form::text('profession', null, ['class' => $errors->has('profession') ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('profession')); ?></small>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo Form::label('phone', 'Phone: '); ?>

                    <?php echo Form::text('phone', null, ['class' => $errors->has('phone') ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('phone')); ?></small>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo Form::label('email', 'Email: '); ?>

                    <?php echo Form::text('email', null, ['class' => $errors->has('email') ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('email')); ?></small>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="row">
                    <div class="col-4">
                        <div class="form-group">
                            <?php echo Form::label('facebook', 'Facebook (url): '); ?>

                            <?php echo Form::url('facebook', null, ['class' => $errors->has('facebook') ? 'form-control is-invalid' : 'form-control']); ?>

                            <small class="text-danger"><?php echo e($errors->first('facebook')); ?></small>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <?php echo Form::label('github', 'Github (url): '); ?>

                            <?php echo Form::url('github', null, ['class' => $errors->has('github') ? 'form-control is-invalid' : 'form-control']); ?>

                            <small class="text-danger"><?php echo e($errors->first('github')); ?></small>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <?php echo Form::label('twitter', 'Twitter (url): '); ?>

                            <?php echo Form::url('twitter', null, ['class' => $errors->has('twitter') ? 'form-control is-invalid' : 'form-control']); ?>

                            <small class="text-danger"><?php echo e($errors->first('twitter')); ?></small>
                        </div>
                    </div>
                    
                </div>
            </div>

            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo Form::label('address', 'Address: '); ?>

                    <?php echo Form::text('address', null, ['class' => $errors->has('address') ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('address')); ?></small>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo Form::label('cv_link', 'CV File: '); ?>

                    <div class="d-block" id="holder2">
                    </div>
                    <div class="input-group">
                        <span class="input-group-btn">
                            <a id="lfm2" data-input="cv_link" data-preview="holder2" class="btn btn-secondary text-white px-4" style="border-top-right-radius: 0; border-bottom-right-radius: 0">
                                Change
                            </a>
                        </span>
                        <?php echo Form::text('cv_link', null, ['id'=>'cv_link', 'class' => $errors->has('cv_link') ? 'form-control is-invalid' : 'form-control']); ?>

                    </div>
                    <small class="text-danger"><?php echo e($errors->first('cv_link')); ?></small>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo Form::label('cover_photo', 'Cover photo: '); ?>

                    <div class="mb-2 d-block" id="holder">
                        <img height="70" src="<?php echo e($about->cover_photo == null ? 'https://via.placeholder.com/100' : $about->cover_photo); ?>" alt="">
                    </div>
                    <div class="input-group">
                        <span class="input-group-btn">
                            <a id="lfm" data-input="cover_photo" data-preview="holder" class="btn btn-secondary text-white px-4" style="border-top-right-radius: 0; border-bottom-right-radius: 0">
                             Change
                            </a>
                        </span>
                        <?php echo Form::text('cover_photo', null, ['class' => $errors->has('cover_photo') ? 'form-control is-invalid' : 'form-control']); ?>

                    </div>
                    <small class="text-danger"><?php echo e($errors->first('cover_photo')); ?></small>
                </div>
            </div>

            

            <div class="col-12">
                <div class="form-group">
                    <?php echo Form::label('short_description', 'Short description: '); ?>

                    <?php echo Form::textarea('short_description', null, ['class' => $errors->has('short_description') ? 'form-control is-invalid' : 'form-control', 'rows'=>3]); ?>

                    <small class="text-danger"><?php echo e($errors->first('short_description')); ?></small>
                </div>
    
                <div class="form-group">
                    <?php echo Form::label('more_description', 'More description: '); ?>

                    <?php echo Form::textarea('more_description', null, ['id' => 'tinyEditor', 'class' => 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('more_description')); ?></small>
                </div>
            
                <?php echo Form::submit('Update Info', ['class' => 'btn btn-success mt-3']); ?>

            </div>

            
        </div>
        

        
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/about/edit.blade.php ENDPATH**/ ?>