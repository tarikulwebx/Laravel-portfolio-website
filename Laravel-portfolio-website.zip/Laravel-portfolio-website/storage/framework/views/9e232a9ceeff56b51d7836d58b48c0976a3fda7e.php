

<?php $__env->startSection('content'); ?>
    <?php if(session('reply_delete_msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('reply_delete_msg')); ?>

        </div>
    <?php endif; ?>
    <h2 class="mb-4">All Replies</h2>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Replies</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTableReplies" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Author</th>
                            <th>Comment</th>
                            <th>Reply</th>
                            <th>Status</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Id</th>
                            <th>Author</th>
                            <th>Comment</th>
                            <th>Reply</th>
                            <th>Status</th>
                            <th>Delete</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if(!empty($replies)): ?>
                            <?php $__currentLoopData = $replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($reply->id); ?></td>
                                    <td style="max-width: 100px">
                                        <span class="d-block"><?php echo e($reply->author); ?></span>
                                        <small><?php echo e($reply->email); ?></small>
                                    </td>
                                    <td style="max-width: 180px"><a href="<?php echo e(url('/posts/' . $reply->comment->post->id . '/#comments')); ?>"><?php echo e(Str::limit($reply->comment->body, 70, '...')); ?></a></td>
                                    <td><?php echo e(Str::limit($reply->body, 120, '...')); ?></td>
                                    <td>
                                        <button id="approveReplyBtn-<?php echo e($reply->id); ?>" class="approveReplyBtn btn btn-primary btn-sm <?php echo e($reply->is_active == 1 ? 'd-none' : ''); ?>" data-id="<?php echo e($reply->id); ?>">Approve</button>
                                        <button id="unApproveReplyBtn-<?php echo e($reply->id); ?>" class="unApproveReplyBtn btn btn-warning btn-sm <?php echo e($reply->is_active == 0 ? 'd-none' : ''); ?>" data-id="<?php echo e($reply->id); ?>">Unapprove</button>
                                    </td>
                                    <td>

                                        <?php echo Form::open(['method' => 'DELETE', 'route' => ['replies.destroy', $reply->id]]); ?>

                                        <?php echo Form::submit('Delete', ['class' => 'deleteReplyBtn btn btn-danger btn-sm']); ?>

                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

    <script>
        
        $(document).ready(function() {
            $('#dataTableReplies').DataTable({
                "pageLength": 10,
                order: [[ 0, "desc" ]],
            });
        });


        $('.approveReplyBtn').click(function(){
            var replyId = $(this).data('id');
            var isActive = 1; //aprove
            
            var url = '/admin/comment/replies/'+replyId;
            axios.put(url, {
                id: replyId,
                is_active: isActive,
            })
            .then(res => {
                if (res.status == 200) {
                    if(res.data == 1) {
                        toastr.success('Reply Approved');
                        $('#approveReplyBtn-'+replyId).addClass('d-none');
                        $('#unApproveReplyBtn-'+replyId).removeClass('d-none');
                    } else {
                        toastr.error('Approve failed');
                        $('#approveReplyBtn-'+replyId).removeClass('d-none');
                        $('#unApproveReplyBtn-'+replyId).addClass('d-none');
                    }
                } else {
                    toastr.error('Approve failed');
                    $('#approveReplyBtn-'+replyId).removeClass('d-none');
                    $('#unApproveReplyBtn-'+replyId).addClass('d-none');
                }
            })
            .catch(err => {
                toastr.error('Error occured');
                $('#approveReplyBtn-'+replyId).removeClass('d-none');
                $('#unApproveReplyBtn-'+replyId).addClass('d-none');
            })

        });


        $('.unApproveReplyBtn').click(function(){
            var replyId = $(this).data('id');
            var isActive = 0; //aprove
            
            var url = '/admin/comment/replies/'+replyId;
            axios.put(url, {
                id: replyId,
                is_active: isActive,
            })
            .then(res => {
                if (res.status == 200) {
                    if(res.data == 1) {
                        toastr.success('Comment Unapproved');
                        $('#approveReplyBtn-'+replyId).removeClass('d-none');
                        $('#unApproveReplyBtn-'+replyId).addClass('d-none');
                    } else {
                        toastr.error('Approve failed');
                        $('#approveReplyBtn-'+replyId).addClass('d-none');
                        $('#unApproveReplyBtn-'+replyId).removeClass('d-none');
                    }
                } else {
                    toastr.error('Approve failed');
                    $('#approveReplyBtn-'+replyId).addClass('d-none');
                    $('#unApproveReplyBtn-'+replyId).removeClass('d-none');
                }
            })
            .catch(err => {
                toastr.error('Error occured');
                $('#approveReplyBtn-'+replyId).addClass('d-none');
                $('#unApproveReplyBtn-'+replyId).removeClass('d-none');
            })

        });


    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/comments/replies/index.blade.php ENDPATH**/ ?>