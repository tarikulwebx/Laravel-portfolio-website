

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul class="m-0">
                    <li><?php echo e($error); ?></li>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    <?php endif; ?>

    <h2 class="mb-3">Category : <?php echo e($category->name); ?></h2>
    <div class="row">
        <div class="col-lg-5 mb-4">
            <?php echo Form::model($category, ['method' => 'PATCH', 'route' => ['categories.update', $category->id]]); ?>

                <div class="form-group">
                    <?php echo Form::label('name', 'Name'); ?>

                    <?php echo Form::text('name', null, ['class' => ($errors->has('name')) ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
                </div>
                <?php echo Form::submit('Update Category', ['class' => 'btn btn-info float-right']); ?>

            <?php echo Form::close(); ?>


            
            <?php echo Form::open(['method' => 'DELETE', 'route' => ['categories.destroy', $category->id]]); ?>

            <?php echo Form::submit('Delete Category', ['class' => 'btn btn-danger float-right mr-3']); ?>

            <?php echo Form::close(); ?>


        </div>
        <div class="col-lg-7">

        </div>
        
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>