

<?php $__env->startSection('content'); ?>
    <a class="btn btn-primary mb-3" href="<?php echo e(route('posts.index')); ?>" role="button"><i class="fas fa-arrow-alt-circle-left   mr-2 "></i>Go Back</a>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="m-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <h2 class="mb-3">New Post</h2>
    <?php echo Form::open(['method' => 'POST', 'route' => 'posts.store', 'files'=>true]); ?>

        <div class="form-group">
            <?php echo Form::label('title', 'Title: '); ?>

            <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

            <small class="text-danger"><?php echo e($errors->first('title')); ?></small>
        </div>

        <div class="form-group">
            <?php echo Form::label('category_id', 'Category: '); ?>

            <?php echo Form::select('category_id', [''=>'Choose category',] + $categories, null, ['class' => 'form-control']); ?>

            <small class="text-danger"><?php echo e($errors->first('category_id')); ?></small>
        </div>

        <div class="form-group">
            <?php echo Form::label('thumbnail', 'Thumbnail: '); ?>

            <div class="mb-3 d-block" id="holder" style="max-height:70px;"></div>
            <div class="input-group">
                <span class="input-group-btn">
                    <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-secondary text-white px-4" style="border-top-right-radius: 0; border-bottom-right-radius: 0">
                      <i class="fa fa-picture-o"></i> Choose
                    </a>
                </span>
                <?php echo Form::text('thumbnail', null, ['class' => 'form-control']); ?>

            </div>
             <small class="text-danger"><?php echo e($errors->first('thumbnail')); ?></small>
        </div>

        <div class="form-group">
            <?php echo Form::label('body', 'Body: '); ?>

            <?php echo Form::textarea('body', null, ['id'=>'tinyEditor', 'class' => 'form-control']); ?>

            <small class="text-danger"><?php echo e($errors->first('body')); ?></small>
        </div>

        <?php echo Form::submit('Create Post', ['class' => 'btn btn-success']); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/admin/posts/create.blade.php ENDPATH**/ ?>