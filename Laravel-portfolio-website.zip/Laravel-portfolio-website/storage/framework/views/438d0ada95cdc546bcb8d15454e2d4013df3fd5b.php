

<?php $__env->startSection('content'); ?>

    <div class="container">

        

        <h2 class="mb-4">Edit Profile</h2>

        <?php echo Form::model($user, ['method' => 'POST', 'route' => ['update-profile', $user->id], 'files'=>true]); ?>

        <div class="row mb-5">
            <div class="col-md-4 col-xl-3">
                <div class="form-group">
                    <?php echo Form::label('photo', 'Profile picture:'); ?>

                    <div class="square-image-box">
                        <img id="image_preview" class="d-block mb-2 img-rendering img-fluid rounded" src="<?php echo e($user->photo ? $user->photo->name : 'https://via.placeholder.com/300'); ?>" alt="">
                    </div>
                    <?php echo Form::file('photo', ['id' => 'image_input_with_preview', 'class' => ($errors->has('photo')) ? 'form-control-file is-invalid' : 'form-control-file']); ?>

                    <small class="text-danger"><?php echo e($errors->first('photo')); ?></small>
                </div>
            </div>
            <div class="col-md-8 col-xl-9">
                <div class="form-group">
                    <?php echo Form::label('name', 'Name: '); ?>

                    <?php echo Form::text('name', null, ['class' => ($errors->has('name')) ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
                </div>

                <div class="form-group">
                    <?php echo Form::label('email', 'Email: '); ?>

                    <?php echo Form::email('email', null, ['class' => ($errors->has('email')) ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('email')); ?></small>
                </div>
                
                <div class="form-group">
                    <?php echo Form::label('password', 'Password: '); ?>

                    <?php echo Form::password('password', ['class' => ($errors->has('password')) ? 'form-control is-invalid' : 'form-control']); ?>

                    <small class="text-danger"><?php echo e($errors->first('password')); ?></small>
                </div>
                
                <div class="text-right float-right">
                    <?php echo Form::submit('Update', ['class' => 'btn btn-orange']); ?>

                </div>
                
            </div>
        </div>
        <?php echo Form::close(); ?>



    </div>

    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\my_portfolio\resources\views/profile/edit.blade.php ENDPATH**/ ?>