@extends('admin.layouts.app')

@section('title', 'Admin CMS')

@section('content')
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Dashboard</h1>
@endsection